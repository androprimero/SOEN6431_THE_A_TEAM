﻿namespace WindowsFormsApplication1
{
    partial class Student_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Student_form));
            this.Back = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.message = new System.Windows.Forms.Label();
            this.Message_show = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.PictureBox();
            this.button4 = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.PictureBox();
            this.Button1 = new System.Windows.Forms.PictureBox();
            this.Form_Pages = new System.Windows.Forms.PictureBox();
            this.icon_show = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.button6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Form_Pages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.icon_show)).BeginInit();
            this.SuspendLayout();
            // 
            // Back
            // 
            this.Back.Location = new System.Drawing.Point(663, 12);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(75, 23);
            this.Back.TabIndex = 1;
            this.Back.Text = "< Logout";
            this.Back.UseVisualStyleBackColor = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 42);
            this.label1.TabIndex = 9;
            this.label1.Text = "Choose From Menu";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // message
            // 
            this.message.AutoSize = true;
            this.message.Location = new System.Drawing.Point(4, 358);
            this.message.Name = "message";
            this.message.Size = new System.Drawing.Size(0, 13);
            this.message.TabIndex = 10;
            // 
            // Message_show
            // 
            this.Message_show.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Message_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Message_show.Location = new System.Drawing.Point(10, 354);
            this.Message_show.Name = "Message_show";
            this.Message_show.Size = new System.Drawing.Size(125, 164);
            this.Message_show.TabIndex = 11;
            this.Message_show.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // button6
            // 
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.Image = global::WindowsFormsApplication1.Properties.Resources.button6_normal;
            this.button6.Location = new System.Drawing.Point(6, 251);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(130, 42);
            this.button6.TabIndex = 8;
            this.button6.TabStop = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            this.button6.MouseLeave += new System.EventHandler(this.button6_MouseLeave);
            this.button6.MouseHover += new System.EventHandler(this.button6_MouseHover);
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Image = global::WindowsFormsApplication1.Properties.Resources.button4_normal;
            this.button4.Location = new System.Drawing.Point(7, 203);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(130, 42);
            this.button4.TabIndex = 6;
            this.button4.TabStop = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            this.button4.MouseLeave += new System.EventHandler(this.button4_MouseLeave);
            this.button4.MouseHover += new System.EventHandler(this.button4_MouseHover);
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Image = global::WindowsFormsApplication1.Properties.Resources.button3_normal;
            this.button3.Location = new System.Drawing.Point(7, 155);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(130, 42);
            this.button3.TabIndex = 5;
            this.button3.TabStop = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            this.button3.MouseLeave += new System.EventHandler(this.button3_MouseLeave);
            this.button3.MouseHover += new System.EventHandler(this.button3_MouseHover);
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Image = global::WindowsFormsApplication1.Properties.Resources.button2_normal;
            this.button2.Location = new System.Drawing.Point(7, 107);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(130, 42);
            this.button2.TabIndex = 4;
            this.button2.TabStop = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            this.button2.MouseLeave += new System.EventHandler(this.button2_MouseLeave);
            this.button2.MouseHover += new System.EventHandler(this.button2_MouseHover);
            // 
            // Button1
            // 
            this.Button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button1.Image = global::WindowsFormsApplication1.Properties.Resources.button1_normal1;
            this.Button1.Location = new System.Drawing.Point(7, 59);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(130, 42);
            this.Button1.TabIndex = 3;
            this.Button1.TabStop = false;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            this.Button1.MouseLeave += new System.EventHandler(this.Button1_MouseLeave);
            this.Button1.MouseHover += new System.EventHandler(this.Button1_MouseHover);
            // 
            // Form_Pages
            // 
            this.Form_Pages.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Form_Pages.Location = new System.Drawing.Point(0, 0);
            this.Form_Pages.Name = "Form_Pages";
            this.Form_Pages.Size = new System.Drawing.Size(137, 798);
            this.Form_Pages.TabIndex = 2;
            this.Form_Pages.TabStop = false;
            // 
            // icon_show
            // 
            this.icon_show.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.icon_show.Location = new System.Drawing.Point(7, 521);
            this.icon_show.Name = "icon_show";
            this.icon_show.Size = new System.Drawing.Size(128, 247);
            this.icon_show.TabIndex = 12;
            this.icon_show.TabStop = false;
            // 
            // Student_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.Student_form;
            this.ClientSize = new System.Drawing.Size(750, 780);
            this.Controls.Add(this.icon_show);
            this.Controls.Add(this.Message_show);
            this.Controls.Add(this.message);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Button1);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.Form_Pages);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Student_form";
            this.Text = "Student_form";
            this.Load += new System.EventHandler(this.Student_form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.button6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Form_Pages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.icon_show)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.PictureBox Form_Pages;
        private System.Windows.Forms.PictureBox Button1;
        private System.Windows.Forms.PictureBox button2;
        private System.Windows.Forms.PictureBox button3;
        private System.Windows.Forms.PictureBox button4;
        private System.Windows.Forms.PictureBox button6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label message;
        private System.Windows.Forms.Label Message_show;
        private System.Windows.Forms.PictureBox icon_show;
    }
}